import re


def is_string(str):
    return bool(re.match('[a-z][A-Z]', str.strip()))


def valid_string(str):
    return str.strip()


def is_empty(str):
    if len(str.strip()) > 0:
        return False
    return True


def valid_email(str):
    regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    if bool(re.fullmatch(regex, str.strip())):
        return {"valid": True, "error": None}
    return {"valid": False, "error": f"invalid email"}


def valid_mobile(num):
    regex = r'\b[0-9]\b'
    if bool(re.fullmatch(regex, num)) and len(num.strip()) == 10:
        return True
    return False


def valid_password_string(str):
    pass


def validation_check_string(str, field):
    if is_empty(str):
        return {"valid": False, "error": f"{field} can't be empty"}

    if not is_string(str):
        return {"valid": False, "error": f"{field} must be string"}

    return {"valid": True, "error": None}


def validation_check_mobile(num, field):
    if is_empty(num):
        return {"valid": False, "error": f"{field} can't be empty"}

    if not valid_mobile(num):
        return {"valid": False, "error": f"invalid mobile number"}

    return {"valid": True, "error": None}
