import json
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.http import JsonResponse
from pathlib import Path
from .validator import *
from django.contrib import messages
from . import models
from django.contrib.auth import authenticate, login, logout
import hmac
import hashlib
from .OyeBot import OyeBot
from .proccess import Proccess_Data
# from OyeChatBot.app import proccess
# from app.proccess import Proccess_Data
# Create your views here.

BASE_DIR = Path(__file__).resolve().parent

print(BASE_DIR)

SECRET_KEY = b'adcb671e8e24572464c31e8f9ffc5f638ab302a0b673f72554d3cff96a692740'


def index(request):

    return render(request, 'index.html', context={'data': "response"})


def customerlogin(request):
    if request.method == 'POST':
        email = request.POST.get('email').strip()
        password = request.POST.get('password').strip()
        fil_email = valid_email(email)

        user = models.Customers.objects.get(email=email)
        if user:
            enc_password = hmac.new(
                SECRET_KEY, password.encode('utf-8'), hashlib.sha256)
            if user.password == enc_password:
                login(request, user)

    return render(request, 'auth/login.html')


def signup(request):
    context = {}
    if request.method == 'POST':
        name = request.POST.get('name').strip()
        username = request.POST.get('username').strip()
        email = request.POST.get('email').strip()
        password = request.POST.get('password').strip()

        fil_name = validation_check_string(name, 'name')
        fil_username = validation_check_string(username, 'username')
        fil_email = valid_email(email)
        # fil_password = validation_check_string(name, 'name')

        if not fil_name['valid']:
            messages.error(request,  fil_name['error'])

        if not fil_username['valid']:
            messages.error(request,
                           fil_username['error'])

        if not fil_email['valid']:
            messages.error(request, fil_email['error'])

        enc_password = hmac.new(
            SECRET_KEY, password.encode('utf-8'), hashlib.sha256)
        user = models.Customers(name=name, email=email,
                                username=username, password=enc_password.hexdigest())
        user.save()
        return redirect('login')

    return render(request, 'auth/register.html', context)


def dashboard(request):
    context = {}
    return render(request, 'dashboard/index.html', context)


def trainBot(request):
    allIntents = models.Intents.objects.all()
    data = {"intents": []}
    listData = []
    for intent in allIntents:
        result = {
            "tag": intent.tag,
            "patterns": intent.patterns.split('|'),
            "responses": intent.responses.split('|')
        }
        listData.append(result)
    data['intents'] = listData
    process = Proccess_Data(data)
    process.start_process()
    messages.success(request, "Dataset Trained Successfully")
    return redirect('addIntents')


def addIntents(request):
    if request.method == 'POST':
        user = models.Customers.objects.get(email="info@gmaiol.com")
        intents = json.loads(request.body.decode('utf-8'))
        patterns = "|".join(intents['patterns'])
        responses = "|".join(intents['responses'])
        # print(type(patterns))
        added_intent = models.Intents(
            customer=user, tag=intents['tag'], patterns=patterns, responses=responses)
        added_intent.save()
        allIntents = models.Intents.objects.values()
        # print(allIntents)
        return JsonResponse({"error": 0, "msg": "saved", "result": list(allIntents)}, safe=False)

    allIntents = models.Intents.objects.all()
    context = {"intents": allIntents}

    return render(request, 'dashboard/intents.html', context)


def getMessage(request):
    if request.method == 'POST':
        req = json.loads(request.body.decode('utf-8'))
        ask = req['ask']
        allIntents = models.Intents.objects.all()
        data = {"intents": []}
        listData = []
        for intent in allIntents:
            result = {
                "tag": intent.tag,
                "patterns": intent.patterns.split('|'),
                "responses": intent.responses.split('|')
            }
            listData.append(result)
        data['intents'] = listData
        bot = OyeBot(data)
        print(ask)
        ans = bot.startChat(ask)
        context = {
            "error": 0,
            "result": ans
        }

        return JsonResponse(context, safe=False)
    return HttpResponse("mesase")
